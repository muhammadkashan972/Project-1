import { RESTAURANT_DATA } from '../data';

export default function SpecialOffers() {
  const { specialOffers } = RESTAURANT_DATA;

  return (
    <section className="py-24 bg-brand-red text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter mb-12">
          {specialOffers.heading}
        </h2>
        <div className="flex flex-wrap justify-center gap-4">
          {specialOffers.offers.map((offer, index) => (
            <div key={index} className="bg-black/20 border border-black/30 px-6 py-4 text-[11px] font-bold uppercase tracking-widest">
              {offer}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
