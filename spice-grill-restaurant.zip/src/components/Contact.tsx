import { RESTAURANT_DATA } from '../data';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { motion } from 'motion/react';

export default function Contact() {
  const { contact } = RESTAURANT_DATA;

  return (
    <section id="contact" className="py-24 bg-[#050505] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-12"
          >
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="h-[1px] w-8 bg-brand-gold"></span>
                <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold">Visit Us</span>
              </div>
              <h2 className="text-5xl md:text-7xl font-black uppercase italic tracking-tighter text-white mb-6">
                {contact.heading}
              </h2>
              <p className="text-zinc-400 max-w-md leading-relaxed">
                Experience Lahore's Best Taste Today. We are open and taking reservations. Feel free to reach out via WhatsApp for quick booking.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-brand-black border border-white/10 flex items-center justify-center shrink-0 text-brand-gold">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-white text-[10px] uppercase font-bold tracking-widest mb-1">Address</h4>
                  <p className="text-gray-400 text-sm font-medium">{contact.address}</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-brand-black border border-white/10 flex items-center justify-center shrink-0 text-brand-gold">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-white text-[10px] uppercase font-bold tracking-widest mb-1">Call / WhatsApp</h4>
                  <p className="text-gray-400 text-sm font-medium">{contact.phone}</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-brand-black border border-white/10 flex items-center justify-center shrink-0 text-brand-gold">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-white text-[10px] uppercase font-bold tracking-widest mb-1">Email</h4>
                  <p className="text-gray-400 text-sm font-medium">{contact.email}</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-brand-black border border-white/10 flex items-center justify-center shrink-0 text-brand-gold">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-white text-[10px] uppercase font-bold tracking-widest mb-1">Opening Hours</h4>
                  <p className="text-gray-400 text-sm font-medium whitespace-pre-line">{contact.hours.replace(': ', ':\n')}</p>
                </div>
              </div>
            </div>
            
            {/* Owner Section built-in to Contact */}
            <div className="p-8 bg-brand-black border border-white/10 mt-8 flex gap-6 items-center">
              <div className="w-16 h-16 bg-[#050505] overflow-hidden shrink-0 border border-white/5">
                <img src="https://ui-avatars.com/api/?name=Kashan+Gill&background=D4AF37&color=fff&rounded=false" alt="Kashan Gill" />
              </div>
              <div>
                <p className="italic text-gray-400 text-sm mb-2 max-w-sm font-medium">"{RESTAURANT_DATA.owner.message}"</p>
                <p className="text-brand-gold font-bold text-[10px] uppercase tracking-widest">— {RESTAURANT_DATA.owner.name}, Owner</p>
              </div>
            </div>

          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-brand-black border border-white/10 p-10"
          >
            <h3 className="text-3xl font-black uppercase tracking-tighter text-white mb-8 border-b border-white/10 pb-4">Reservation Form</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <input type="text" placeholder="Your Name" className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-white text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors" />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <input type="text" placeholder="Phone Number" className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-white text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors" />
                <input type="number" placeholder="Guests" min="1" className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-white text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors" />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <input type="date" className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-gray-400 text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors" />
                <input type="time" className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-gray-400 text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors" />
              </div>
              <div>
                <textarea placeholder="Special Requests" rows={3} className="w-full bg-[#050505] border border-white/10 px-5 py-4 text-white text-sm font-medium focus:outline-none focus:border-brand-gold transition-colors"></textarea>
              </div>
              <button className="w-full bg-brand-red hover:bg-red-800 text-white font-bold uppercase tracking-[0.3em] text-[11px] py-5 transition-colors">
                Book Table
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
