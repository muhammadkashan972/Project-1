import { MessageCircle } from 'lucide-react';
import { RESTAURANT_DATA } from '../data';

export default function FloatingWhatsApp() {
  let rawNumber = RESTAURANT_DATA.contact.phone.replace(/[^0-9]/g, '');
  if (rawNumber.startsWith('0')) {
    rawNumber = '92' + rawNumber.substring(1);
  }
  const phoneNumber = rawNumber;

  return (
    <a
      href={`https://wa.me/${phoneNumber}?text=Hi,%20I%20would%20like%20to%20reserve%20a%20table%20or%20place%20an%20order.`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-[0_4px_14px_0_rgba(37,211,102,0.39)] hover:-translate-y-1 hover:shadow-[0_6px_20px_rgba(37,211,102,0.23)] transition-all duration-300 group"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-7 h-7" />
      {/* Tooltip */}
      <span className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-[#050505] text-brand-gold text-[10px] font-bold uppercase tracking-widest px-4 py-2 border border-brand-gold shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Order via WhatsApp
        <span className="absolute top-1/2 -right-1.5 -translate-y-1/2 border-y-4 border-y-transparent border-l-[6px] border-l-brand-gold"></span>
      </span>
    </a>
  );
}
