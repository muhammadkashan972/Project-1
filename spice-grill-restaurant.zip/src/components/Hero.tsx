import { RESTAURANT_DATA } from '../data';
import { ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

export default function Hero() {
  const { hero } = RESTAURANT_DATA;

  return (
    <section id="home" className="relative relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
          alt="Delicious BBQ" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/80 via-zinc-950/60 to-zinc-950"></div>
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <span className="h-[1px] w-12 bg-brand-gold"></span>
            <span className="text-brand-gold text-xs font-bold uppercase tracking-[0.3em]">Welcome to Spice Grill</span>
            <span className="h-[1px] w-12 bg-brand-gold"></span>
          </div>

          <h1 className="text-6xl md:text-8xl font-black mb-6 leading-[0.9] uppercase italic tracking-tighter">
            {hero.heading.split(' ').map((word, i) => (
              <span key={i} className={i === 0 ? "text-brand-red" : "text-white"}> {word}</span>
            ))}
          </h1>
          
          <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            {hero.subheading}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="#menu" 
              className="w-full sm:w-auto bg-brand-red hover:bg-red-800 text-white px-8 py-4 text-sm font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2"
            >
              Order Now <ChevronRight className="w-4 h-4" />
            </a>
            <a 
              href="#contact" 
              className="w-full sm:w-auto bg-white hover:bg-gray-200 text-black px-8 py-4 text-sm font-bold uppercase tracking-widest transition-colors flex items-center justify-center"
            >
              Reserve Table
            </a>
          </div>

          <div className="mt-12 pt-8 border-t border-white/10 flex justify-center gap-8 items-center">
            <div>
              <div className="text-2xl font-bold text-brand-gold">5000+</div>
              <div className="text-[10px] text-gray-500 uppercase tracking-widest">Happy Customers</div>
            </div>
            <div className="w-[1px] h-8 bg-white/10"></div>
            <div className="text-[11px] text-gray-400 italic font-mono max-w-xs text-left">
              Fresh Ingredients • Fast Service
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
