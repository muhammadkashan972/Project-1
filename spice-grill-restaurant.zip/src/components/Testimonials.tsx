import { RESTAURANT_DATA } from '../data';
import { Star, Quote } from 'lucide-react';
import { motion } from 'motion/react';

export default function Testimonials() {
  const { reviews } = RESTAURANT_DATA;

  return (
    <section id="reviews" className="py-24 bg-brand-black border-y border-white/10 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-[#050505]/50 clip-path-slant z-0"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
         <div className="text-center mb-16">
           <div className="flex items-center justify-center gap-3 mb-4">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-brand-gold uppercase tracking-[0.3em] font-bold text-[10px]">Testimonials</span>
              <span className="h-[1px] w-8 bg-brand-gold"></span>
            </div>
            <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter text-white">
              {reviews.heading}
            </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.items.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-[#050505] border border-white/10 p-10 relative group hover:border-brand-gold/30 transition-colors"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-white/5 group-hover:text-brand-gold/10 transition-colors" />
              <div className="flex gap-1 mb-6 text-brand-gold">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-current" />)}
              </div>
              <p className="text-gray-400 leading-relaxed italic text-sm font-medium">
                "{review}"
              </p>
              <div className="mt-8 flex items-center gap-4 border-t border-white/10 pt-6">
                <div className="w-10 h-10 bg-brand-black flex items-center justify-center font-black text-brand-gold tracking-tighter">
                  C{index + 1}
                </div>
                <div>
                  <h4 className="text-white text-[11px] font-bold uppercase tracking-widest">Customer</h4>
                  <span className="text-[10px] font-bold text-brand-red uppercase tracking-widest">Verified Diner</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
