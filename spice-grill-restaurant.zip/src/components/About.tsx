import { RESTAURANT_DATA } from '../data';
import { motion } from 'motion/react';

export default function About() {
  const { about } = RESTAURANT_DATA;

  return (
    <section id="about" className="py-24 bg-brand-black border-y border-white/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Image Side */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] object-cover rounded-3xl overflow-hidden relative">
              <img 
                src="https://images.unsplash.com/photo-1544025162-811c79a92ab8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Restaurant interior" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-3xl"></div>
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-6 lg:-right-12 bg-zinc-900 border border-white/10 p-6 rounded-2xl shadow-xl flex items-center gap-4">
              <div className="text-brand-red">
                <span className="text-4xl font-black italic tracking-tighter">10+</span>
              </div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 leading-tight">
                Years of <br /> Experience
              </div>
            </div>
          </motion.div>

          {/* Text Side */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="mb-6 flex items-center gap-3">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-brand-gold uppercase tracking-[0.3em] font-bold text-[10px]">Discover Our Story</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter mb-8 text-white">
              {about.heading}
            </h2>
            
            <div className="space-y-6 text-gray-400 leading-relaxed font-medium">
              {about.content.map((paragraph, index) => (
                <p key={index} className={index === 0 ? "text-lg text-white font-bold" : ""}>
                  {paragraph}
                </p>
              ))}
            </div>

            <div className="mt-10">
              <a 
                href="#menu" 
                className="inline-block border-b border-brand-red pb-1 text-brand-red hover:text-white hover:border-white transition-colors uppercase tracking-[0.3em] text-[11px] font-bold"
              >
                View Full Menu
              </a>
            </div>
          </motion.div>
          
        </div>
      </div>
    </section>
  );
}
