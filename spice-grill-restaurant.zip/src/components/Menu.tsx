import { RESTAURANT_DATA } from '../data';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Menu() {
  const { menu, familyDeals } = RESTAURANT_DATA;
  const [activeCategory, setActiveCategory] = useState(menu[0].category);

  return (
    <section id="menu" className="py-24 bg-zinc-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-brand-gold uppercase font-bold tracking-[0.3em] text-[10px]">Discover</span>
              <span className="h-[1px] w-8 bg-brand-gold"></span>
            </div>
            <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter text-white mb-10">
              Our Full Menu
            </h2>

            {/* Category Navigation Pills */}
            <div className="flex flex-wrap justify-center gap-3">
              {menu.map((category) => (
                <button
                  key={category.category}
                  onClick={() => setActiveCategory(category.category)}
                  className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-all ${
                    activeCategory === category.category
                      ? 'bg-brand-red text-white'
                      : 'bg-brand-black text-gray-400 hover:text-white border border-white/5'
                  }`}
                >
                  {category.category}
                </button>
              ))}
              <button
                 onClick={() => setActiveCategory('Family Deals')}
                 className={`px-6 py-3 text-[11px] font-bold uppercase tracking-widest transition-all ${
                    activeCategory === 'Family Deals'
                      ? 'bg-brand-gold text-black'
                      : 'bg-brand-black border border-brand-gold/30 text-brand-gold hover:bg-brand-gold hover:text-black'
                  }`}
              >
                Family Deals
              </button>
            </div>
        </div>

        {/* Menu Items */}
        <div className="max-w-4xl mx-auto min-h-[400px]">
          <AnimatePresence mode="wait">
            {activeCategory !== 'Family Deals' ? (
              <motion.div
                key={activeCategory}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="grid md:grid-cols-2 gap-x-12 gap-y-8"
              >
                {menu.find(c => c.category === activeCategory)?.items.map((item, idx) => (
                  <div key={idx} className="flex flex-col border-b border-white/5 pb-4">
                    <div className="flex justify-between items-end mb-2">
                      <h4 className="text-lg font-bold text-white/90">{item.name}</h4>
                      <span className="text-brand-gold font-mono text-xl whitespace-nowrap pl-4">{item.price}</span>
                    </div>
                  </div>
                ))}
              </motion.div>
            ) : (
               <motion.div
                key="Family Deals"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="grid md:grid-cols-3 gap-8"
              >
                {familyDeals.map((deal, idx) => (
                  <div key={idx} className="bg-brand-black border border-white/10 p-10 text-center flex flex-col h-full">
                    <h4 className="text-3xl font-black uppercase tracking-tighter text-white mb-2">{deal.name}</h4>
                    <div className="text-brand-gold font-mono text-xl mb-6 pb-6 border-b border-white/10">{deal.price}</div>
                    <ul className="space-y-4 mb-8 grow text-gray-400 text-sm font-medium uppercase tracking-widest">
                      {deal.items.map((i, iIdx) => (
                        <li key={iIdx}>{i}</li>
                      ))}
                    </ul>
                    <a href="#contact" className="w-full block bg-brand-red hover:bg-red-900 text-white py-4 text-[11px] font-bold transition-colors uppercase tracking-widest">
                      Order Deal
                    </a>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
