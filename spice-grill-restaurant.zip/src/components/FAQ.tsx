import { RESTAURANT_DATA } from '../data';
import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function FAQ() {
  const { faq } = RESTAURANT_DATA;
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section className="py-24 bg-[#050505] border-b border-white/10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter text-white mb-6">
            {faq.heading}
          </h2>
        </div>

        <div className="space-y-4">
          {faq.items.map((item, idx) => (
            <div 
              key={idx} 
              className="border border-white/10 bg-brand-black overflow-hidden"
            >
              <button
                onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                className="w-full px-8 py-6 flex justify-between items-center text-left"
              >
                <span className="font-bold text-white text-[11px] uppercase tracking-widest">{item.q}</span>
                {openIdx === idx ? (
                  <Minus className="w-5 h-5 text-brand-gold shrink-0" />
                ) : (
                  <Plus className="w-5 h-5 text-zinc-500 shrink-0" />
                )}
              </button>
              
              <AnimatePresence>
                {openIdx === idx && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-8 pb-6 text-gray-400 font-medium leading-relaxed border-t border-white/5 pt-4">
                      {item.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
