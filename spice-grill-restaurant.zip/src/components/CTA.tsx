import { RESTAURANT_DATA } from '../data';
import { Phone, Utensils } from 'lucide-react';

export default function CTA() {
  const { cta } = RESTAURANT_DATA;

  return (
    <section className="py-32 bg-brand-black border-y border-white/10 relative overflow-hidden">
      <div className="absolute inset-0 bg-brand-red/10 border-t-8 border-brand-red mix-blend-overlay pointer-events-none"></div>
      <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
        <h2 className="text-6xl md:text-8xl font-black uppercase italic tracking-tighter text-white mb-6">
          {cta.heading}
        </h2>
        <p className="text-xl text-gray-400 font-medium mb-10 max-w-2xl mx-auto">
          {cta.content}
        </p>
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <a 
              href="#contact" 
              className="w-full sm:w-auto bg-brand-red hover:bg-red-800 text-white px-8 py-5 font-bold transition-colors uppercase tracking-[0.3em] text-[11px] flex items-center justify-center gap-3"
            >
              <Phone className="w-4 h-4" /> Book Table
            </a>
            <a 
              href="#menu" 
              className="w-full sm:w-auto bg-white hover:bg-gray-200 text-black px-8 py-5 font-bold transition-colors uppercase tracking-[0.3em] text-[11px] flex items-center justify-center gap-3"
            >
              <Utensils className="w-4 h-4" /> Order Online
            </a>
          </div>
      </div>
    </section>
  );
}
