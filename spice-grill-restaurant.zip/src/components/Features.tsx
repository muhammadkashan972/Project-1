import { RESTAURANT_DATA } from '../data';
import { motion } from 'motion/react';
import { 
  Leaf, Users, Clock, Tag, 
  Star, UserCheck, ShieldCheck, 
  Car, Smartphone, Moon
} from 'lucide-react';

const iconMap: Record<string, any> = {
  "Fresh Daily Ingredients": Leaf,
  "Family Friendly Environment": Users,
  "Fast Serving Time": Clock,
  "Affordable Prices": Tag,
  "Premium Taste": Star,
  "Professional Staff": UserCheck,
  "Hygienic Kitchen": ShieldCheck,
  "Free Parking": Car,
  "Online Ordering Available": Smartphone,
  "Late Night Dining": Moon
};

export default function Features() {
  const { features } = RESTAURANT_DATA;

  return (
    <section className="py-24 bg-brand-black relative border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-16">
           <div className="flex items-center justify-center gap-3 mb-4">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold">Our Advantages</span>
              <span className="h-[1px] w-8 bg-brand-gold"></span>
            </div>
            <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter text-white">
              {features.heading}
            </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 gap-y-12">
          {features.points.map((point, index) => {
            const Icon = iconMap[point] || Star;
            return (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="flex flex-col items-center text-center"
              >
                <div className="w-16 h-16 bg-[#050505] border border-white/10 flex items-center justify-center mb-4 text-brand-red hover:text-black hover:bg-brand-red transition-colors">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{point}</h3>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  );
}
