import { Facebook, Instagram, Twitter } from 'lucide-react'; // Twitter acts as TikTok placeholder or just use custom svg

export default function Footer() {
  return (
    <footer className="bg-brand-black pt-20 pb-10 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          
          <div className="md:col-span-1">
            <a href="#home" className="text-3xl font-black uppercase tracking-tighter text-brand-gold mb-6 flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-red flex items-center justify-center">
                <span className="text-brand-gold font-bold text-lg">S</span>
              </div>
              Spice Grill
            </a>
            <p className="text-gray-400 text-sm font-medium leading-relaxed mb-6">
              Serving the best family restaurant dining experience in Lahore with fresh ingredients and traditional recipes.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-[#050505] border border-white/10 flex items-center justify-center text-gray-400 hover:text-brand-gold transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 bg-[#050505] border border-white/10 flex items-center justify-center text-gray-400 hover:text-brand-gold transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 bg-[#050505] border border-white/10 flex items-center justify-center text-gray-400 hover:text-brand-gold transition-all">
                 <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold tracking-[0.3em] mb-6 uppercase text-[10px]">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'About Us', 'Menu', 'Gallery', 'Reviews', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '-')}`} className="text-gray-400 font-bold uppercase tracking-widest hover:text-brand-gold text-[10px] transition-colors block">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
             <h4 className="text-white font-bold tracking-[0.3em] mb-6 uppercase text-[10px]">Contact Info</h4>
             <ul className="space-y-4 text-sm font-medium text-gray-400">
               <li>Phone: 0300-4812972</li>
               <li>Email: kashankmkmg@gmail.com</li>
               <li>Main Boulevard DHA Lahore</li>
             </ul>
          </div>

          <div>
             <h4 className="text-white font-bold tracking-[0.3em] mb-6 uppercase text-[10px]">Newsletter</h4>
             <p className="text-gray-400 font-medium text-sm mb-4">Subscribe to get special offers and updates.</p>
             <form className="flex" onSubmit={(e) => e.preventDefault()}>
               <input type="email" placeholder="Your Email" className="bg-[#050505] border border-white/10 px-4 py-3 w-full text-white text-sm font-medium focus:outline-none focus:border-brand-gold" />
               <button className="bg-brand-red hover:bg-red-800 text-white font-bold px-6 py-3 text-[11px] uppercase tracking-widest transition-colors">
                 Join
               </button>
             </form>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 text-center md:flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-gray-500">
          <p>© 2026 Spice Grill Restaurant — Owned by Kashan Gill. All Rights Reserved.</p>
          <div className="flex gap-4 justify-center mt-4 md:mt-0">
             <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
             <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
