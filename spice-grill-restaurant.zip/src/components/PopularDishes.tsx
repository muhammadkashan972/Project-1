import { RESTAURANT_DATA } from '../data';
import { motion } from 'motion/react';

export default function PopularDishes() {
  const { popularDishes } = RESTAURANT_DATA;

  // Placeholder images mapping
  const dishImages = [
    "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", // Biryani
    "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", // BBQ Platter
    "https://images.unsplash.com/photo-1606471206149-8c4d1663f4ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", // Karahi
    "https://images.unsplash.com/photo-1529042410759-befb1204b468?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", // Tikka
  ];

  return (
    <section className="py-24 bg-brand-dark border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold">Tastes Good</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-black uppercase italic tracking-tighter text-white">
              {popularDishes.heading}
            </h2>
          </div>
          <a href="#menu" className="text-brand-red uppercase tracking-[0.3em] text-[10px] font-bold flex items-center gap-1 hover:text-white transition-colors">
            See All Menu &rarr;
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {popularDishes.items.slice(0, 4).map((dish, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-[4/3] rounded-2xl overflow-hidden mb-4 relative">
                <img 
                  src={dishImages[index] || "https://images.unsplash.com/photo-1544025162-811c79a92ab8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"} 
                  alt={dish} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                   <span className="bg-brand-red text-white text-[10px] font-bold px-3 py-1 uppercase tracking-widest">Must Try</span>
                </div>
              </div>
              <h3 className="text-xl font-bold uppercase tracking-widest text-white group-hover:text-brand-gold transition-colors">{dish}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
