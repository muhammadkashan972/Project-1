/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Features from './components/Features';
import PopularDishes from './components/PopularDishes';
import Menu from './components/Menu';
import SpecialOffers from './components/SpecialOffers';
import Testimonials from './components/Testimonials';
import Gallery from './components/Gallery';
import FAQ from './components/FAQ';
import CTA from './components/CTA';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';

export default function App() {
  return (
    <div className="bg-zinc-950 min-h-screen text-zinc-50 relative">
      <Navbar />
      <Hero />
      <About />
      <PopularDishes />
      <Features />
      <Menu />
      <SpecialOffers />
      <Testimonials />
      <Gallery />
      <FAQ />
      <CTA />
      <Contact />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
