export const RESTAURANT_DATA = {
  hero: {
    heading: "Best Family Restaurant in Lahore",
    subheading: "Fresh BBQ, Traditional Pakistani Taste, Fast Service, and Premium Family Dining Experience in Lahore.",
    trustLine: "5000+ Happy Customers • Fresh Ingredients • Fast Service",
  },
  about: {
    heading: "About Our Restaurant",
    content: [
      "Welcome to Spice Grill Restaurant, where authentic Pakistani flavors meet modern family dining. We are passionate about serving fresh, delicious, and high-quality meals made with premium ingredients and traditional recipes.",
      "From BBQ platters to spicy biryani and freshly grilled specialties, our goal is simple — deliver unforgettable taste and excellent customer service.",
      "Whether you are visiting with family, friends, or colleagues, we provide a comfortable environment, fast service, and food that keeps customers coming back.",
      "Our chefs focus on quality, hygiene, and consistency in every dish."
    ]
  },
  features: {
    heading: "Why Customers Love Us",
    points: [
      "Fresh Daily Ingredients",
      "Family Friendly Environment",
      "Fast Serving Time",
      "Affordable Prices",
      "Premium Taste",
      "Professional Staff",
      "Hygienic Kitchen",
      "Free Parking",
      "Online Ordering Available",
      "Late Night Dining"
    ]
  },
  popularDishes: {
    heading: "Customer Favorite Dishes",
    items: [
      "Chicken Biryani",
      "Beef BBQ Platter",
      "Chicken Karahi",
      "Mutton Handi",
      "Chicken Tikka",
      "Malai Boti",
      "Zinger Burger",
      "Alfredo Pasta",
      "Fresh Naans",
      "Special Dessert"
    ]
  },
  reviews: {
    heading: "What Our Customers Say",
    items: [
      "Amazing taste and excellent family environment. One of the best BBQ restaurants in Lahore.",
      "Fast service, clean dining area, and delicious food. Highly recommended.",
      "Their biryani and BBQ platter were outstanding. Definitely visiting again.",
      "Very professional staff and affordable prices. Great experience overall."
    ]
  },
  cta: {
    heading: "Ready to Taste the Best Food in Lahore?",
    content: "Reserve your table today or order online for a fresh and delicious dining experience."
  },
  menu: [
    {
      category: "BBQ",
      items: [
        { name: "Chicken Tikka", price: "Rs. 850" },
        { name: "Malai Boti", price: "Rs. 1200" },
        { name: "Chicken Seekh Kebab", price: "Rs. 950" },
        { name: "Beef Seekh Kebab", price: "Rs. 1100" },
        { name: "Chicken Reshmi Kebab", price: "Rs. 1150" },
        { name: "Beef Bihari Boti", price: "Rs. 1450" },
        { name: "Mutton Chops", price: "Rs. 2800" },
        { name: "Full BBQ Platter", price: "Rs. 4990" },
      ]
    },
    {
      category: "Biryani",
      items: [
        { name: "Chicken Biryani", price: "Rs. 450" },
        { name: "Beef Biryani", price: "Rs. 650" },
        { name: "Special Biryani", price: "Rs. 850" },
        { name: "Family Pack Biryani", price: "Rs. 1990" },
      ]
    },
    {
      category: "Karahi & Handi",
      items: [
        { name: "Chicken Karahi Half", price: "Rs. 1650" },
        { name: "Chicken Karahi Full", price: "Rs. 2950" },
        { name: "Mutton Karahi Half", price: "Rs. 3200" },
        { name: "Mutton Karahi Full", price: "Rs. 5990" },
        { name: "White Chicken Handi", price: "Rs. 1890" },
        { name: "Makhni Handi", price: "Rs. 1990" },
      ]
    },
    {
      category: "Fast Food",
      items: [
        { name: "Zinger Burger", price: "Rs. 690" },
        { name: "Beef Burger", price: "Rs. 850" },
        { name: "Loaded Fries", price: "Rs. 650" },
        { name: "Chicken Shawarma", price: "Rs. 390" },
        { name: "Club Sandwich", price: "Rs. 750" },
        { name: "Crispy Broast", price: "Rs. 1190" },
      ]
    },
    {
      category: "Pizza",
      items: [
        { name: "Chicken Fajita", price: "S: Rs. 890 | M: Rs. 1590 | L: Rs. 2290", description: "" },
        { name: "Pepperoni Pizza", price: "S: Rs. 990 | M: Rs. 1690 | L: Rs. 2490", description: "" },
        { name: "BBQ Pizza", price: "S: Rs. 950 | M: Rs. 1650 | L: Rs. 2390", description: "" },
        { name: "Crown Crust Special", price: "S: Rs. 1190 | M: Rs. 1990 | L: Rs. 2890", description: "" },
      ]
    },
    {
      category: "Chinese",
      items: [
        { name: "Chicken Manchurian", price: "Rs. 1450" },
        { name: "Chicken Chowmein", price: "Rs. 1190" },
        { name: "Egg Fried Rice", price: "Rs. 850" },
        { name: "Chicken Fried Rice", price: "Rs. 1090" },
        { name: "Hot & Sour Soup", price: "Rs. 690" },
      ]
    },
    {
      category: "Desserts",
      items: [
        { name: "Gulab Jamun", price: "Rs. 290" },
        { name: "Chocolate Brownie", price: "Rs. 450" },
        { name: "Ice Cream Scoop", price: "Rs. 250" },
        { name: "Molten Lava Cake", price: "Rs. 690" },
        { name: "Cheese Cake", price: "Rs. 790" },
      ]
    },
    {
      category: "Drinks",
      items: [
        { name: "Mint Margarita", price: "Rs. 450" },
        { name: "Fresh Lime", price: "Rs. 350" },
        { name: "Cold Drink Can", price: "Rs. 220" },
        { name: "Mineral Water", price: "Rs. 120" },
        { name: "Tea", price: "Rs. 180" },
        { name: "Coffee", price: "Rs. 350" },
      ]
    }
  ],
  familyDeals: [
    {
      name: "Deal 1",
      price: "Rs. 2990",
      items: ["1 Chicken Karahi Half", "4 Naans", "Salad", "1.5L Drink"]
    },
    {
      name: "Deal 2",
      price: "Rs. 4990",
      items: ["Full BBQ Platter", "Large Pizza", "6 Naans", "Dessert", "1.5L Drink"]
    },
    {
      name: "Deal 3",
      price: "Rs. 7990",
      items: ["Mutton Karahi Full", "BBQ Platter", "Biryani", "Desserts", "Drinks"]
    }
  ],
  specialOffers: {
    heading: "Today’s Special Offers",
    offers: [
      "Buy 1 Get 1 Zinger Every Tuesday",
      "20% OFF on Family Deals",
      "Free Drink with Large Pizza",
      "Student Discount Available",
      "Free Dessert on Birthday Celebration"
    ]
  },
  deliveryAreas: {
    heading: "We Deliver In",
    areas: ["DHA Lahore", "Johar Town", "Gulberg", "Bahria Town", "Model Town", "Cantt", "Faisal Town"]
  },
  faq: {
    heading: "Frequently Asked Questions",
    items: [
      { q: "Do you offer home delivery?", a: "Yes, fast delivery available across Lahore." },
      { q: "Do you accept online payments?", a: "Yes, JazzCash, EasyPaisa, bank transfer, and cash accepted." },
      { q: "Do you offer family seating?", a: "Yes, premium family halls available." },
      { q: "Do you take birthday bookings?", a: "Yes, birthday and event bookings available." }
    ]
  },
  owner: {
    name: "Kashan Gill",
    message: "At Spice Grill Restaurant, our mission is simple — serve fresh, high-quality food with outstanding customer service. We focus on taste, hygiene, and creating a comfortable family dining experience for every guest."
  },
  contact: {
    heading: "Contact Spice Grill Restaurant",
    address: "Main Boulevard DHA Lahore, Pakistan",
    phone: "0300-4812972",
    email: "kashankmkmg@gmail.com",
    hours: "Monday – Sunday: 12:00 PM – 2:00 AM"
  }
};
